<?php
$file = $_GET['file'];
$filepath = "projects_zip/" . $file;

if (file_exists($filepath)) {
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
    readfile($filepath);
    exit;
} else {
    echo "File not found.";
}
?>
