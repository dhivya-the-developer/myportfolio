<div class="header">
  <h1 class="site-title">My Portfolio</h1>

  <div class="header-right">
    <a href="index.php" class="nav-btn">Home</a>
    <a href="projects.php" class="nav-btn">My Projects</a>
  </div>
</div>

<marquee behavior="scroll" direction="left" class="marquee">
  "Build websites that inspire. Code with passion. Create without limits."
</marquee>
