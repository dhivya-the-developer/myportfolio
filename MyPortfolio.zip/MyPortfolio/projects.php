<?php include 'header.php'; ?>
<link rel="stylesheet" href="assets/style.css">

<div class="main-container">
  <h2>My Projects</h2>

  <?php
  // Include database connection
  include 'db.php';

  $query = "SELECT * FROM projects ORDER BY id DESC";
  $result = mysqli_query($conn, $query);

  while($row = mysqli_fetch_assoc($result)) {
      echo "<div class='project-card'>";
      echo "<h3>" . htmlspecialchars($row['project_name']) . "</h3>";
      echo "<p>" . nl2br(htmlspecialchars($row['project_description'])) . "</p>";
      echo "<a class='btn' href='" . $row['project_link'] . "' target='_blank'>View Project</a>";
      echo "<a class='btn' href='" . $row['download_link'] . "' download>Download ZIP</a>";
      echo "</div>";
  }

  ?>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<?php include 'footer.php'; ?>
