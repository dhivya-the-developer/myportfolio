<?php include 'header.php'; ?>
<?php include 'db.php'; ?>
<head>
<link rel="stylesheet" href="assets/style.css">
</head>
<div class="main-container">
    <div class="profile">
        <img src="assets/dhivya.jpg" alt="Profile Image">
        <div class="info">
            <h2>Dhivyashree</h2>
            <p>BSc Computer Science</p>
            <p>Email: divyasridivya84@gmail.com</p>
            <p>Phone: 9095267399</p>
            <p>LinkedIn: <a href="#">linkedin.com/in/dhivyashree</a></p>
            <p>Instagram: <a href="#">@dhivyashree</a></p>
            <p>GitHub: <a href="#">github.com/dhivyashree</a></p>
            <a href="assets/resume.pdf" class="btn" download>Download Resume</a>
        </div>
    </div>

    <div class="about">
        <h2>About Me</h2>
        <p>I am seeking a challenging opportunity as a Web Developer. Passionate about building engaging and responsive websites. Dedicated to delivering elegant code and innovative user experiences. Let my code do the talking!</p>
        <p><strong>Coding Skills:</strong> HTML, CSS, PHP, MySQL, JavaScript</p>
    </div>
</div>

<?php include 'footer.php'; ?>
