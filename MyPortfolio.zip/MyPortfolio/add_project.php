<?php include 'db.php'; ?>
<form method="POST" enctype="multipart/form-data">
    <input type="text" name="name" placeholder="Project Name" required><br>
    <input type="text" name="link" placeholder="Project Link" required><br>
    <textarea name="description" placeholder="Project Description" required></textarea><br>
    <input type="file" name="zip" accept=".zip" required><br>
    <input type="submit" name="submit" value="Add Project">
</form>

<?php
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $link = $_POST['link'];
    $description = $_POST['description'];
    $zip = $_FILES['zip']['name'];
    $zip_tmp = $_FILES['zip']['tmp_name'];

    move_uploaded_file($zip_tmp, "projects_zip/" . $zip);

    $stmt = $conn->prepare("INSERT INTO projects (name, link, description, download) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $link, $description, $zip);
    $stmt->execute();
    echo "Project added!";
}
?>
