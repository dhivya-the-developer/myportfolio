<link rel="stylesheet" href="assets/style.css">

<div class="footer">
    <p>&copy; 2025 Dhivyashree | Web Developer</p>
</div>
